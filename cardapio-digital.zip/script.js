let pedido = [];
let total = 0;

function adicionarItem(nome, preco) {
  pedido.push({ nome, preco });
  total += preco;
  atualizarPedido();
}

function atualizarPedido() {
  const lista = document.getElementById("lista-pedido");
  const totalElem = document.getElementById("total");
  const linkWhatsApp = document.getElementById("btn-whatsapp");

  lista.innerHTML = "";
  pedido.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
    lista.appendChild(li);
  });

  totalElem.textContent = total.toFixed(2);

  const textoPedido = pedido.map(p => `• ${p.nome} - R$ ${p.preco}`).join("\n");
  const mensagem = `Olá! Gostaria de fazer o seguinte pedido:\n\n${textoPedido}\n\nTotal: R$ ${total.toFixed(2)}`;
  const telefone = "5521970459073"; // Número de WhatsApp com DDD

  linkWhatsApp.href = `https://wa.me/${telefone}?text=${encodeURIComponent(mensagem)}`;
}
